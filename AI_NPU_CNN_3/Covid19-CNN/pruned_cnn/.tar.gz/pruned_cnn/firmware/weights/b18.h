//Numpy array shape [6]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 6

#ifndef B18_H_
#define B18_H_

#ifndef __SYNTHESIS__
bias18_t b18[6];
#else
bias18_t b18[6] = {1.6975945234, 0.5557035208, 1.8007857800, 1.0322910547, -2.4942083359, -2.2105572224};
#endif

#endif
