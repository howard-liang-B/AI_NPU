//Numpy array shape [2]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 2

#ifndef B7_H_
#define B7_H_

#ifndef __SYNTHESIS__
bias7_t b7[2];
#else
bias7_t b7[2] = {0.2036143988, 0.5050481558};
#endif

#endif
