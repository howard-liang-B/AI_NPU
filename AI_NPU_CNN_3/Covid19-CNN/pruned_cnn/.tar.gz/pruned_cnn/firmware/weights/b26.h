//Numpy array shape [4]
//Min -0.277812302113
//Max 0.098476000130
//Number of zeros 0

#ifndef B26_H_
#define B26_H_

#ifndef __SYNTHESIS__
output_dense_bias_t b26[4];
#else
output_dense_bias_t b26[4] = {0.0984760001, -0.2778123021, 0.0935185924, 0.0748943016};
#endif

#endif
