# ==============================================================
# Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2020.2 (64-bit)
# Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
# ==============================================================

/mnt/Data/Xilinx/Vivado/2020.2/bin/vivado  -notrace -mode batch -source ipi_example.tcl -tclargs xc7z020-clg484-1 ../xilinx_com_hls_myproject_1_0.zip
