//Numpy array shape [4]
//Min -0.225387543440
//Max 0.118353545666
//Number of zeros 0

#ifndef B23_H_
#define B23_H_

#ifndef __SYNTHESIS__
output_dense_bias_t b23[4];
#else
output_dense_bias_t b23[4] = {0.1183535457, -0.2253875434, -0.0181395225, -0.0783091858};
#endif

#endif
