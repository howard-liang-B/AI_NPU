//Numpy array shape [6]
//Min -0.169712454081
//Max 0.773243188858
//Number of zeros 0

#ifndef B17_H_
#define B17_H_

#ifndef __SYNTHESIS__
bn_dense_0_bias_t b17[6];
#else
bn_dense_0_bias_t b17[6] = {-0.1697124541, 0.6474258900, 0.7411229014, 0.3099834323, 0.7732431889, 0.6246754527};
#endif

#endif
