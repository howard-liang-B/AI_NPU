//Numpy array shape [2]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 2

#ifndef B10_H_
#define B10_H_

#ifndef __SYNTHESIS__
bias10_t b10[2];
#else
bias10_t b10[2] = {0.0625, 1.0000};
#endif

#endif
