//Numpy array shape [24]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 24

#ifndef B19_H_
#define B19_H_

#ifndef __SYNTHESIS__
bias19_t b19[24];
#else
bias19_t b19[24] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
#endif

#endif
