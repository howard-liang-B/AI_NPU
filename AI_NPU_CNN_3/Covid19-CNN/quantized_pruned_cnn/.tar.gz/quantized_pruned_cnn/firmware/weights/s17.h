//Numpy array shape [6]
//Min 0.423554122448
//Max 1.095811724663
//Number of zeros 0

#ifndef S17_H_
#define S17_H_

#ifndef __SYNTHESIS__
bn_dense_0_scale_t s17[6];
#else
bn_dense_0_scale_t s17[6] = {0.8682763577, 0.9269089699, 0.4235541224, 0.8697089553, 1.0958117247, 0.8470322490};
#endif

#endif
